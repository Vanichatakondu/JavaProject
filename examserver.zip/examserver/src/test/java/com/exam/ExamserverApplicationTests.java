package com.exam;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;

import com.exam.model.User;
import com.exam.repository.UserRepository;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ExamserverApplicationTests {
	
	@Autowired
	UserRepository userRepository;

	@Test
	@Order(1)
	public void getUserTesting()
	{
		User user = this.userRepository.findByUsername("durgesh2295");
		System.out.println(user+"********");
		 assertNotNull(user.getUsername());
	}

	

}
